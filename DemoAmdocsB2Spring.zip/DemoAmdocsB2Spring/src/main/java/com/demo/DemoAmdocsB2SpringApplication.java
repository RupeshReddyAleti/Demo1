package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAmdocsB2SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAmdocsB2SpringApplication.class, args);
	}

}
